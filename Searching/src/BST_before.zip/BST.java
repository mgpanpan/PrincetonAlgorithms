public class BST<Key extends Comparable<Key>, Value>
{
    private Node root;
    private class Node
    {
        private Key key;
        private Value val;
        private Node left, right;
        private int N;

        /* Add x and y coordinate for BST drawing */
        private double x_coordinate, y_coordinate;

        /*
         * when using this constructor, returns an isolated point, whose
         * left and right links are null.
         */
        public Node(Key key, Value val, int N)
        {  this.key = key; this.val = val; this.N = N;  }
    }

    public Value get(Key key)
    {  return get(root, key);  }

    private Value get(Node x, Key key)
    {
        if (x == null)    return null;
        int cmp = key.compareTo(x.key);
        if (cmp < 0)      return get(x.left, key);
        else if (cmp > 0) return get(x.right, key);
        else              return x.val;
    }
    
    public void put(Key key, Value val)
    {  root = put(root, key, val);  }

    private Node put(Node x, Key key, Value val)
    {
        if (x == null)    return new Node(key, val, 1);
        int cmp = key.compareTo(x.key);
        if (cmp < 0)      x.left  = put(x.left, key, val);
        else if (cmp > 0) x.right = put(x.right, key, val);
        else              x.val   = val;
        x.N = size(x.left) + size(x.right) + 1;
        return x;
    }

    public int size()
    {  return size(root);  }

    private int size(Node x)
    {
        if (x == null)  return 0;
        else            return x.N;
    }

    public boolean contains(Key key)
    {  return get(key) != null;  }

    public boolean isEmpty()
    {  return size() == 0;  }

    /* iterative version */
    /*
    public Key min()
    {
        Node x = root;
        while (x.left != null)
            x = x.left;
        return x.key;
    }
    */

    /* iterative version */
    /*
    public Key max()
    {
        Node x = root;
        while (x.right != null)
            x = x.right;
        return x.key;
    }
    */

    public Key min()
    {  return min(root).key;  }

    private Node min(Node x)
    {
        if (x == null)      return null;
        if (x.left == null) return x;
        else return min(x.left);
    }

    public Key max()
    {  return max(root).key;  }

    public Node max(Node x)
    {
        if (x == null)       return null;
        if (x.right == null) return x;
        else return max(x.right);
    }

    public Key floor(Key key)
    {
        Node x = floor(root, key);
        if (x == null) return null;
        else           return x.key;
    }

    private Node floor(Node x, Key key)
    {
        if (x == null)  return null;
        int cmp = key.compareTo(x.key);
        if (cmp == 0)   return x;
        if (cmp < 0)    return floor(x.left, key);
        Node t = floor(x.right, key);
        if (t == null)  return x;
        else            return t;
    }

    public Key ceiling(Key key)
    {
        Node x = ceiling(root, key);
        if (x == null) return null;
        else           return x.key;

    }

    private Node ceiling(Node x, Key key)
    {
        if (x == null) return null;
        int cmp = key.compareTo(x.key);
        if (cmp == 0)  return x;
        if (cmp > 0)   return ceiling(x.right, key);
        Node t = ceiling(x.left, key);
        if (t == null) return x;
        else           return t;
    }

    public Key select(int k)
    {
        /* the rank of the elements of the BST must be in range 0 ~ size()-1 */
        if (k < 0 || k >= size())  return null;
        return select(root, k).key;
    }

    private Node select(Node x, int k)
    {
        if (x == null)  return null;
        int t = size(x.left);
        if      (t > k) return select(x.left, k);
        else if (t < k) return select(x.right, k-t-1);
        else            return x;
    }

    public int rank(Key key)
    {
        return rank(root, key);
    }

    private int rank(Node x, Key key)
    {
        if (x == null)    return 0;
        int cmp = key.compareTo(x.key);
        if      (cmp < 0) return rank(x.left, key);
        else if (cmp > 0) return size(x.left) + 1 + rank(x.right, key);
        else              return size(x.left);
    }

    public void deleteMin()
    {  root = deleteMin(root);  }

    private Node deleteMin(Node x)
    {
        if (x == null)      return null;
        if (x.left == null) return x.right;
        x.left = deleteMin(x.left);
        x.N = size(x.left) + size(x.right) + 1;
        return x;
    }

    public void deleteMax()
    {  root = deleteMax(root);  }

    private Node deleteMax(Node x)
    {
        if (x == null)       return null;
        if (x.right == null) return x.left;
        x.right = deleteMax(x.right);
        x.N = size(x.left) + size(x.right) + 1;
        return x;
    }

    public void delete(Key key)
    {  root = delete(root, key);  }

    private Node delete(Node x, Key key)
    {
        if (x == null)  return null;
        int cmp = key.compareTo(x.key);
        if      (cmp < 0)   x.left = delete(x.left, key);
        else if (cmp > 0)  x.right = delete(x.right, key);
        else
        {
            if (x.right == null) return x.left;
            if (x.left == null)  return x.right;
            Node t = x;
            x = min(t.right);
            x.right = deleteMin(t.right);
            x.left = t.left;
        }
        x.N = size(x.left) + size(x.right) + 1;
        return x;
    }

    public Iterable<Key> keys()
    {  return keys(min(), max());  }

    public Iterable<Key> keys(Key lo, Key hi)
    {
        Queue<Key> queue = new Queue<Key>();
        keys(root, queue, lo, hi);
        return queue;
    }

    private void keys(Node x, Queue<Key> queue, Key lo, Key hi)
    {
        if (x == null)  return;
        int cmplo = lo.compareTo(x.key);
        int cmphi = hi.compareTo(x.key);
        if (cmplo < 0) keys(x.left, queue, lo, hi);
        if (cmplo <= 0 && cmphi >= 0) queue.enqueue(x.key);
        if (cmphi > 0) keys(x.right, queue, lo, hi);
    }

    public Iterable<Key> keysLevelOrder()
    {
        Queue<Key> queue = new Queue<Key>();
        queue.enqueue(root.key);
        keysLevelOrder(root, queue);
        return queue;
    }

    private void keysLevelOrder(Node x, Queue<Key> queue)
    {
        if (x == null) return;
        if (x.left != null)  queue.enqueue(x.left.key);
        if (x.right != null) queue.enqueue(x.right.key);
        keysLevelOrder(x.left, queue);
        keysLevelOrder(x.right, queue);
    }

    public void print()
    {
        if (root.right != null)
            printTree(root.right, true, "");
        printNodeValue(root);
        if (root.left != null)
            printTree(root.left, false, "");
        StdOut.println();
    }

    private void printNodeValue(Node x)
    {
        if (x == null) return;
        else StdOut.print("(" + x.key.toString() + "," + x.val.toString() + ") " + x.N);
        StdOut.println();
    }

    // use string and not stringbuffer on purpose as we need to change the indent at each recursion
    private void printTree(Node x, boolean isRight, String indent)
    {
        if (x.right != null)
            printTree(x.right, true, indent + (isRight ? "        " : " |      "));

        StdOut.print(indent);
        if (isRight) StdOut.print(" /");
        else StdOut.print(" \\");

        StdOut.print("----- ");
        printNodeValue(x);
        if (x.left != null)
            printTree(x.left, false, indent + (isRight ? " |      " : "        "));
    }

    public void draw()
    {
        Draw canvas = new Draw("BST");
        int canvas_radio = 2;
        canvas.setCanvasSize(500*canvas_radio, 500);
        double x_min = -1.0, x_max = 1.0, y_min = 0.0, y_max = 2.0;
        double x_range = x_max - x_min;
        double y_range = y_max - y_min;
        canvas.setXscale(x_min - x_range / 5, x_max + x_range / 5);
        canvas.setYscale(y_min - y_range / 5, y_max + y_range / 5);
        setCoordinate(x_min, x_max, y_min, y_max);

        int h = height();
        double x_num = Math.pow(2, h);
        /* the x interval of the lowest layer */
        double x_interval_lowest = x_range / (x_num - 1);
        double r1 = x_interval_lowest / 3;
        if (r1 > 0.05) r1 = r1 / 10;
        double r2 = r1 * canvas_radio;

        draw(canvas, r1, r2, root);
    }

    public void draw(Draw canvas, double r1, double r2, Node x)
    {
        if (x == null) return;
        canvas.filledEllipse(x.x_coordinate, x.y_coordinate, r1, r2);
        canvas.text(x.x_coordinate - r2, x.y_coordinate + r2 * 2, x.key.toString());
        canvas.setPenColor(canvas.RED);
        canvas.text(x.x_coordinate - r2, x.y_coordinate - r2 * 2, x.val.toString());
        canvas.setPenColor();
        canvas.text(x.x_coordinate - r2, x.y_coordinate - r2 * 5, Integer.toString(x.N));
        if (x.left != null)
            canvas.line(x.x_coordinate, x.y_coordinate, x.left.x_coordinate, x.left.y_coordinate);
        if (x.right != null)
            canvas.line(x.x_coordinate, x.y_coordinate, x.right.x_coordinate, x.right.y_coordinate);
        draw(canvas, r1, r2, x.left);
        draw(canvas, r1, r2, x.right);
    }

    private void setCoordinate(double x_min, double x_max, double y_min, double y_max)
    {
        double x_range = x_max - x_min;
        double y_range = y_max - y_min;
        int h = height();
        double x_num = Math.pow(2, h);
        /* the x interval of the lowest layer */
        double x_interval_lowest = x_range / (x_num - 1);
        double x_interval = x_interval_lowest * Math.pow(2, h-2);
        double y_interval = y_range / (h - 1);
        setCoordinate(root, (x_min + x_max) / 2, y_max, x_interval, y_interval);
    }

    private void setCoordinate(Node x, double x_cor, double y_cor, double x_interval, double y_interval)
    {
        if (x == null) return;
        x.x_coordinate = x_cor;
        x.y_coordinate = y_cor;
        setCoordinate(x.left, x_cor - x_interval / 2, y_cor - y_interval, x_interval / 2, y_interval);
        setCoordinate(x.right, x_cor + x_interval / 2, y_cor - y_interval, x_interval / 2, y_interval);
    }

    public int height()
    {
        return height(root);
    }

    private int height(Node x)
    {
        if (x == null) return 0;
        else return Math.max(height(x.left), height(x.right)) + 1;
    }

    public static void main(String[] args)
    {
        BST<String, Integer> st;
        st = new BST<String, Integer>();
        In in = new In(args[0]);
        for (int i = 0; !in.isEmpty(); i++)
        {
            String key = in.readString();
            st.put(key, i);
            st.print();
            st.draw();
        }
        st.print();
        StdOut.println("============================ Origin BST ========================");
        StdOut.println("----------------- Inorder traversal: ---------------------------");
        for (String s : st.keys())
            StdOut.print(s + " ");
        StdOut.println();
        StdOut.println("---------------- Level order traversal: ------------------------");
        for (String s : st.keysLevelOrder())
            StdOut.print(s + " ");
        StdOut.println();

        StdOut.print("Size of this BST: ");
        StdOut.println(st.size());
        StdOut.print("Height of this BST: ");
        StdOut.println(st.height());

        StdOut.println("Max key: " + st.max());
        StdOut.println("Min key: " + st.min());

        st.print();
        st.draw();

        /* delete test */
        StdOut.println();
        StdOut.println("============================  Delete test: ===================== ");
        StdOut.println("================ Delete minimum ==================");
        st.deleteMin();

        StdOut.println("---------------------- Inorder traversal: -----------------------");
        for (String s : st.keys())
            StdOut.print(s + " ");
        StdOut.println();
        StdOut.println("----------------------- Level order traversal: ------------------");
        for (String s : st.keysLevelOrder())
            StdOut.print(s + " ");
        StdOut.println();

        StdOut.print("Size of this BST: ");
        StdOut.println(st.size());
        StdOut.print("Height of this BST: ");
        StdOut.println(st.height());
        st.draw();
        st.print();

        StdOut.println("============== Delete Maximum ================== ");
        st.deleteMax();

        StdOut.println("--------------------- Inorder traversal: ------------------- ");
        for (String s : st.keys())
            StdOut.print(s + " ");
        StdOut.println();
        StdOut.println("-------------------- Level order traversal: ----------------- ");
        for (String s : st.keysLevelOrder())
            StdOut.print(s + " ");
        StdOut.println();

        StdOut.print("Size of this BST: ");
        StdOut.println(st.size());
        StdOut.print("Height of this BST: ");
        StdOut.println(st.height());
        st.draw();
        st.print();

        StdOut.println("================== Delete Key 'M' =================");
        st.delete("M");

        StdOut.println("--------------------- Inorder traversal: ------------------- ");
        for (String s : st.keys())
            StdOut.print(s + " ");
        StdOut.println();
        StdOut.println("-------------------- Level order traversal: ----------------- ");
        for (String s : st.keysLevelOrder())
            StdOut.print(s + " ");
        StdOut.println();

        StdOut.print("Size of this BST: ");
        StdOut.println(st.size());
        StdOut.print("Height of this BST: ");
        StdOut.println(st.height());
        st.draw();
        st.print();

        StdOut.println("============== Delete Key 'F'(not in the BST) =========");
        st.delete("F");

        StdOut.println("--------------------- Inorder traversal: ------------------- ");
        for (String s : st.keys())
            StdOut.print(s + " ");
        StdOut.println();
        StdOut.println("-------------------- Level order traversal: ----------------- ");
        for (String s : st.keysLevelOrder())
            StdOut.print(s + " ");
        StdOut.println();

        StdOut.print("Size of this BST: ");
        StdOut.println(st.size());
        StdOut.print("Height of this BST: ");
        StdOut.println(st.height());
        st.draw();
        st.print();

        /* floor test */
        StdOut.println();
        StdOut.println("========================== floor test ====================== ");
        StdOut.println("floor of D: " + st.floor("D"));
        StdOut.println("floor of A: " + st.floor("A"));
        StdOut.println("floor of Y: " + st.floor("Y"));
        StdOut.println("floor of T: " + st.floor("T"));

        /* ceiling test */
        StdOut.println();
        StdOut.println("========================== ceiling test ====================== ");
        StdOut.println("ceiling of D: " + st.ceiling("D"));
        StdOut.println("ceiling of A: " + st.ceiling("A"));
        StdOut.println("ceiling of Y: " + st.ceiling("Y"));
        StdOut.println("ceiling of T: " + st.ceiling("T"));

        /* select test */
        StdOut.println();
        StdOut.println("========================== select test ====================== ");
        StdOut.println("select rank 0: " + st.select(0));
        StdOut.println("select rank 7: " + st.select(7));
        StdOut.println("select rank 6: " + st.select(6));
        StdOut.println("select rank 3: " + st.select(3));

        /* rank test */
        StdOut.println();
        StdOut.println("========================== rank test ====================== ");
        StdOut.println("rank of A: " + st.rank("A"));
        StdOut.println("rank of X: " + st.rank("X"));
        StdOut.println("rank of C: " + st.rank("C"));
        StdOut.println("rank of D: " + st.rank("D"));

        /* contains test */
        StdOut.println();
        StdOut.println("========================== contains test ====================");
        StdOut.println("whether contains D: " + st.contains("D"));
        StdOut.println("whether contains C: " + st.contains("C"));

        /* isEmpty test */
        StdOut.println();
        StdOut.println("========================== isEmpty test ====================");
        StdOut.println("whether empty: " + st.isEmpty());
        int N = st.size();
        for (int i = 0; i < N; i++)
            st.deleteMin();
        StdOut.println("whether empty: " + st.isEmpty());

        /* exercise3.2.1 */
        StdOut.println("Exercise 3.2.1 ");
        BST<String, Integer> st2;
        st2 = new BST<String, Integer>();
        String[] tmp = {"E", "A", "S", "Y", "Q", "U", "E", "S", "T", "I", "O", "N"};
        for (int i = 0; i < tmp.length; i++)
        {
            st2.put(tmp[i], i);
            st2.print();
            st2.draw();
        }
        st2.print();
    }
}

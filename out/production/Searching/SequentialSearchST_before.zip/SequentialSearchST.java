import java.util.Iterator;

public class SequentialSearchST<Key, Value>
{
    private Node first = null;

    private class Node
    {
        Key key;
        Value val;
        Node next;
        public Node(Key key, Value val, Node next)
        {
            this.key = key;
            this.val = val;
            this.next = next;
        }
    }

    public Value get(Key key)
    {
        for (Node x = first; x != null; x = x.next)
            if (key.equals(x.key)) return x.val;    // search hit
        return null;    // search miss
    }

    public void put(Key key, Value val)
    {
        for (Node x = first; x != null; x = x.next)
            if (key.equals(x.key))
            {  x.val = val; return;  }     // search hit
        first = new Node(key, val, first); // search miss
    }

    // eager delete
    public void delete(Key key)
    {
        if (first == null) return;
        for (Node x = first; x != null; x = x.next)
        {
            Node x_next = x.next;
            if (key.equals(x.key))
            {  first = x_next; return;  }
            else if (key.equals(x_next.key))
            {  x.next = x_next.next; return;  }
        }
        return;  // key is not existed in current symbol table
    }
    
    public int size()
    {
        int num = 0;
        for (Node x = first; x != null; x = x.next)
            num++;
        return num;
    }

    // lazy delete
    // public void delete(Key key)
    // {  put(key, null);  }

    public boolean contains(Key key)
    {  return get(key) != null;  }

    public boolean isEmpty()
    {  return size() == 0;  }

    public Iterable<Key> keys()
    {
        return new KeyCollection();
    }

    private class KeyCollection implements Iterable<Key>
    {
        public Iterator<Key> iterator()
        {  return new ListIterator();  }
    }

    private class ListIterator implements Iterator<Key>
    {
        private Node current = first;
        
        public boolean hasNext()
        {  return current != null;  }
        public void remove()
        {  return;  }
        public Key next()
        {
            Key key = current.key;
            current = current.next;
            return key;
        }
    }
    
    public static void main(String[] args)
    {
        SequentialSearchST<String, Integer> st;
        st = new SequentialSearchST<String, Integer>();
        In in = new In(StdIn.readString());
        for (int i = 0; !in.isEmpty(); i++)
        {
            String key = in.readString();
            st.put(key, i);
        }
        for (String s : st.keys())
            StdOut.println(s + " " + st.get(s));
        StdOut.println();

        st.delete("L");
        for (String s : st.keys())
            StdOut.println(s + " " + st.get(s));
        StdOut.println();

        st.delete("S");
        for (String s : st.keys())
            StdOut.println(s + " " + st.get(s));
        StdOut.println();

        st.delete("X");
        for (String s : st.keys())
            StdOut.println(s + " " + st.get(s));
        StdOut.println();
    }
}
